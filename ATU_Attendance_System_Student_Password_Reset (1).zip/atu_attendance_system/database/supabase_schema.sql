-- ATU Student Attendance Management System database
-- Run in Supabase Dashboard > SQL Editor > New query.
-- Authentication uses Supabase Auth; never store plain-text passwords in these tables.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('administrator', 'coordinator', 'student');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.attendance_status as enum ('Present', 'Absent', 'Late', 'Excused');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  role public.app_role not null default 'student',
  student_number text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  course_code text not null unique,
  course_name text not null,
  lecturer_name text,
  credit_hours integer not null default 3 check (credit_hours between 1 and 10),
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.course_registrations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  registered_at timestamptz not null default now(),
  unique(student_id, course_id)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  attendance_date date not null default current_date,
  status public.attendance_status not null,
  note text,
  marked_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(student_id, course_id, attendance_date)
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  max_score numeric(7,2) not null check (max_score > 0),
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(course_id, title)
);

create table if not exists public.student_scores (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  score numeric(7,2) not null check (score >= 0),
  entered_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now(),
  unique(assessment_id, student_id)
);

create index if not exists idx_registrations_student on public.course_registrations(student_id);
create index if not exists idx_attendance_student_date on public.attendance_records(student_id, attendance_date);
create index if not exists idx_assessments_course on public.assessments(course_id);
create index if not exists idx_scores_student on public.student_scores(student_id);

-- Helper functions used by Row Level Security policies.
create or replace function public.current_app_role()
returns public.app_role language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_app_role() in ('administrator', 'coordinator'), false) $$;

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.course_registrations enable row level security;
alter table public.attendance_records enable row level security;
alter table public.assessments enable row level security;
alter table public.student_scores enable row level security;

-- Profiles: users can read their own profile; staff can read profiles; users can update their own non-role fields.
drop policy if exists "profiles read own or staff" on public.profiles;
create policy "profiles read own or staff" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_staff());
drop policy if exists "profiles update own basic fields" on public.profiles;
create policy "profiles update own basic fields" on public.profiles for update to authenticated
using (id = auth.uid() or public.current_app_role() = 'administrator')
with check (id = auth.uid() or public.current_app_role() = 'administrator');
drop policy if exists "administrator creates profiles" on public.profiles;
create policy "administrator creates profiles" on public.profiles for insert to authenticated
with check (public.current_app_role() = 'administrator' or (id = auth.uid() and role = 'student'));

-- Courses: authenticated users can view courses; only staff can manage them.
drop policy if exists "authenticated view courses" on public.courses;
create policy "authenticated view courses" on public.courses for select to authenticated using (true);
drop policy if exists "staff manage courses" on public.courses;
create policy "staff manage courses" on public.courses for all to authenticated
using (public.is_staff()) with check (public.is_staff());

-- Registrations: students manage their own registrations; staff can manage all.
drop policy if exists "read own registrations or staff" on public.course_registrations;
create policy "read own registrations or staff" on public.course_registrations for select to authenticated
using (student_id = auth.uid() or public.is_staff());
drop policy if exists "students register themselves or staff manage" on public.course_registrations;
create policy "students register themselves or staff manage" on public.course_registrations for insert to authenticated
with check ((student_id = auth.uid() and public.current_app_role() = 'student') or public.is_staff());
drop policy if exists "delete own registrations or staff" on public.course_registrations;
create policy "delete own registrations or staff" on public.course_registrations for delete to authenticated
using (student_id = auth.uid() or public.is_staff());

-- Attendance: students read their own records; staff can record and manage attendance.
drop policy if exists "read attendance own or staff" on public.attendance_records;
create policy "read attendance own or staff" on public.attendance_records for select to authenticated
using (student_id = auth.uid() or public.is_staff());
drop policy if exists "staff manage attendance" on public.attendance_records;
create policy "staff manage attendance" on public.attendance_records for all to authenticated
using (public.is_staff()) with check (public.is_staff());

-- Assessments: users can view assessments; only staff can create or change them.
drop policy if exists "authenticated view assessments" on public.assessments;
create policy "authenticated view assessments" on public.assessments for select to authenticated using (true);
drop policy if exists "staff manage assessments" on public.assessments;
create policy "staff manage assessments" on public.assessments for all to authenticated
using (public.is_staff()) with check (public.is_staff());

-- Scores: students see only their own scores; staff manage scores.
drop policy if exists "read own scores or staff" on public.student_scores;
create policy "read own scores or staff" on public.student_scores for select to authenticated
using (student_id = auth.uid() or public.is_staff());
drop policy if exists "staff manage scores" on public.student_scores;
create policy "staff manage scores" on public.student_scores for all to authenticated
using (public.is_staff()) with check (public.is_staff());

-- Important: assign the first administrator securely from the Supabase SQL editor after creating
-- that user's Auth account. Do not allow public sign-up to choose an administrator role.
